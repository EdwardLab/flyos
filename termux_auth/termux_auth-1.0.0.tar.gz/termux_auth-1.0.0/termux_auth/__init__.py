"""为termux_auth提供二次封装"""
# 导入ctypes库
import ctypes

# 加载termux-auth库
termux_auth = ctypes.CDLL('/data/data/com.termux/files/usr/lib/libtermux-auth.so')

def change_passwd(newpasswd):
    """修改密码"""
    pwd = ctypes.create_string_buffer(
            newpasswd.encode(),
            len(newpasswd)
            )
    return termux_auth.termux_change_passwd(pwd)

def auth(passwd):
    """验证密码"""
    user = ctypes.create_string_buffer(
            b"termux",
            6
            )
    pwd = ctypes.create_string_buffer(
            passwd.encode(),
            len(passwd)
            )
    return termux_auth.termux_auth(user, pwd)

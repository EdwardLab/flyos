from setuptools import setup, find_packages

setup(
    name="termux_auth",
    version="1.0.0",

    description="termux_auth",
    long_description="termux_auth的二次分装, 用起来方便点",

    author="xkdr1234",
    author_email="1525098017@qq.com",

    packages=find_packages(),
    install_requires=[],
)
